export default function CenteredHeader({ inputText }) {
  return <div style={{ textAlign: 'center' }}>{inputText}</div>;
}
