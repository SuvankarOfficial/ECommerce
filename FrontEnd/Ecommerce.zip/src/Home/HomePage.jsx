import '../css/HomePage.css';

export default function HomePage() {
  return (
    <div className="home-page">
      <div className="content-side">Now this is somwthing</div>
      <div className="index-side">Is ain't it?</div>
    </div>
  );
}
